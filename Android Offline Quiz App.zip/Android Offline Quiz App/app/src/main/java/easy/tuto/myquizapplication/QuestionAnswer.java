package easy.tuto.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "How many days are there in a week?",
            "How many hours are there in a day?",
            "How many days are there in a year?",
            "Name the National bird of India?",
            "Name the National river of India",
            "Name the biggest continent in the world?",
            "Name the largest planet of our Solar System?",
            "Name the hardest substance available on Earth?",
            "Which continent is known as the ‘Dark’ continent?",
            "Name the longest river on the Earth?"

    };

    public static String choices[][] = {
            {"9 Days","15 Days","12 Days","7 Days"},
            {"24 hours","48 hours","30 hours","28 hours"},
            {"399 days","365 days","400 days","900 days"},
            {"Monkey","Lion","Peacock","Tiger"},
            {"Ganga","Narmada","Godavari","Brahmaputra"},
            {"Antarctica","Asia","Africa","Europe"},
            {"Jupiter","Venus","Earth","Neptune"},
            {"Metallic Glass","Diamond","Silicon Carbide","Lonsdaleite"},
            {"Africa","Antarctica","Europe","Asia"},
            {"River Nile","Amazon River","Yangtze River","Mississippi River"}
    };

    public static String correctAnswers[] = {
            "7 Days",
            "24 hours",
            "365 days",
            "Peacock",
            "Ganga",
            "Asia",
            "Jupiter",
            "Diamond",
            "Africa",
            "River Nile"
    };

}
